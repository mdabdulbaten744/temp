#!/usr/bin/env python3
"""Newspaper Cutout Studio - 4 hero clips, recorded headless on GitHub Actions.
Ported from the Colab notebook. Reads the app from ./app/*.html, writes MP4s to ./output/."""
import os, sys, glob, math, time, random, shutil, asyncio, threading, subprocess, base64, csv, bisect
import http.server, socketserver
from playwright.async_api import async_playwright

# ───────────────────────── SETTINGS (env-overridable) ─────────────────────────
APP_URL    = os.environ.get("APP_URL", "")
RESOLUTION = os.environ.get("RESOLUTION", "1080p")
SEED       = int(os.environ.get("SEED", "2026"))

DURATION     = 15.0
FPS          = 30
JPEG_QUALITY = 100
CRF          = 14
SLIDER_HOLD  = 5.8
DESKTOP      = dict(w=1280, h=720, dsf=1.5 if RESOLUTION == "1080p" else 2.0)
HERE         = os.path.dirname(os.path.abspath(__file__))
ROOT         = os.path.join(HERE, "output")
TMP_ROOT     = os.path.join(HERE, "_tmp")
APP_DIR      = os.path.join(HERE, "_served")

# ───────────────────────── GET THE APP ─────────────────────────
print("⏳ Preparing app…", flush=True)
URL = APP_URL
if not URL:
    cands = sorted(glob.glob(os.path.join(HERE, "app", "*.html")), key=lambda p: ("cutout" not in p.lower(), p))
    if not cands:
        raise SystemExit("No HTML file found in ./app/. Put your app .html there.")
    print("   using:", os.path.basename(cands[0]), flush=True)
    shutil.rmtree(APP_DIR, ignore_errors=True)
    os.makedirs(APP_DIR)
    shutil.copy(cands[0], os.path.join(APP_DIR, "index.html"))

    class Quiet(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=APP_DIR, **k)
        def log_message(self, *a):
            pass

    socketserver.TCPServer.allow_reuse_address = True
    httpd = socketserver.ThreadingTCPServer(("127.0.0.1", 0), Quiet)
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    URL = f"http://127.0.0.1:{httpd.server_address[1]}/index.html"

# ═══ @@LIB_START ═══
# ───────────────────── on-screen cursor (injected into every page) ─────────────────────
CURSOR_JS = r"""
(() => {
  const boot = () => {
    if (document.getElementById("__fc")) return;
    const st = document.createElement("style");
    st.textContent = `
#__fc{position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;pointer-events:none;opacity:0;will-change:transform}
#__fc .a{position:absolute;left:-3px;top:-2px;filter:drop-shadow(0 2px 3px rgba(0,0,0,.5));transform-origin:3px 2px;transition:transform .1s ease}
#__fc.down .a{transform:scale(.78)}
.__rip{position:fixed;width:16px;height:16px;margin:-8px 0 0 -8px;border-radius:50%;border:3px solid rgba(240,38,28,.95);pointer-events:none;z-index:2147483646;animation:__rip .55s ease-out forwards}
@keyframes __rip{from{transform:scale(.3);opacity:1}to{transform:scale(4);opacity:0}}`;
    document.documentElement.appendChild(st);
    const fc = document.createElement("div");
    fc.id = "__fc";
    fc.innerHTML = '<svg class="a" width="32" height="32" viewBox="0 0 24 24"><path d="M3 2l7.6 19.2 2.7-8 8-2.7z" fill="#fff" stroke="#111" stroke-width="1.5" stroke-linejoin="round"/></svg>';
    document.documentElement.appendChild(fc);
    const rip = (x, y) => {
      const r = document.createElement("div");
      r.className = "__rip"; r.style.left = x + "px"; r.style.top = y + "px";
      document.documentElement.appendChild(r);
      setTimeout(() => r.remove(), 650);
    };
    const mv = (x, y) => { fc.style.transform = "translate(" + x + "px," + y + "px)"; fc.style.opacity = "1"; };
    addEventListener("mousemove", e => mv(e.clientX, e.clientY), true);
    addEventListener("mousedown", e => { mv(e.clientX, e.clientY); fc.classList.add("down"); rip(e.clientX, e.clientY); }, true);
    addEventListener("mouseup", () => fc.classList.remove("down"), true);
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
"""

TILES_JS = """() => { try {
  const r = canvas.getBoundingClientRect();
  return lastTiles.filter(t => t.sx != null).map(t => ({
    x: r.left + t.sx * r.width / canvas.width, y: r.top + t.sy * r.height / canvas.height, uid: t.uid })); }
  catch (e) { return []; } }"""

VISIBLE_JS = """(ids) => ids.filter(id => {
  const e = document.getElementById(id); if (!e) return false;
  const r = e.getBoundingClientRect();
  if (r.width < 10 || r.height < 2) return false;
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  if (cx < 0 || cy < 0 || cx > innerWidth || cy > innerHeight) return false;
  const top = document.elementFromPoint(cx, cy);
  return top === e || e.contains(top);
})"""

LIGHT_JS = r"""() => {
  const pick = el => { const m = getComputedStyle(el).backgroundColor.match(/[\d.]+/g); return m ? m.map(Number) : null; };
  for (const el of [document.body, document.documentElement]) {
    const c = pick(el);
    if (c && (c.length < 4 || c[3] > 0.5)) return (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
  }
  return null;
}"""

# ───────────────────────── smooth path helpers ─────────────────────────
def build_path(pts, per=40):
    """Catmull-Rom spline through pts -> dense polyline + cumulative arc length."""
    P = [pts[0]] + list(pts) + [pts[-1]]
    out = []
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for k in range(per):
            t = k / per; t2 = t * t; t3 = t2 * t
            out.append(tuple(0.5 * ((2 * p1[a]) + (-p0[a] + p2[a]) * t +
                                    (2 * p0[a] - 5 * p1[a] + 4 * p2[a] - p3[a]) * t2 +
                                    (-p0[a] + 3 * p1[a] - 3 * p2[a] + p3[a]) * t3) for a in (0, 1)))
    out.append(tuple(pts[-1]))
    cum = [0.0]
    for a, b in zip(out, out[1:]):
        cum.append(cum[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    return out, cum

def path_at(path, cum, f):
    d = max(0.0, min(1.0, f)) * cum[-1]
    i = min(max(1, bisect.bisect_left(cum, d)), len(cum) - 1)
    seg = (cum[i] - cum[i - 1]) or 1.0
    u = (d - cum[i - 1]) / seg
    a, b = path[i - 1], path[i]
    return a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u

def smoother(u):
    u = max(0.0, min(1.0, u))
    return u * u * u * (u * (6 * u - 15) + 10)

MOVE_DT = 0.010   # ~90 Hz pointer updates

# ───────────────────────── the "robot hand" ─────────────────────────
class Rig:
    def __init__(self, page, rng, W, H):
        self.page, self.rng, self.W, self.H = page, rng, W, H
        self.x, self.y = W / 2, H / 2
        self.t0 = time.perf_counter()
        self.log = []

    def now(self):
        return time.perf_counter() - self.t0

    async def sleep(self, s):
        if s > 0:
            await asyncio.sleep(s)

    async def until(self, t):
        await self.sleep(t - self.now())

    async def place(self, x, y):
        self.x, self.y = x, y
        await self.page.mouse.move(x, y)

    async def glide(self, x, y, dur=0.6):
        """time-based eased move along a slightly curved path"""
        x0, y0 = self.x, self.y
        if math.hypot(x - x0, y - y0) < 2:
            return
        dx, dy = x - x0, y - y0
        off = self.rng.uniform(-0.10, 0.10)
        cx, cy = (x0 + x) / 2 - dy * off, (y0 + y) / 2 + dx * off
        ts = time.perf_counter()
        while True:
            u = (time.perf_counter() - ts) / dur
            if u >= 1:
                break
            e = smoother(u)
            await self.page.mouse.move((1 - e) ** 2 * x0 + 2 * (1 - e) * e * cx + e * e * x,
                                       (1 - e) ** 2 * y0 + 2 * (1 - e) * e * cy + e * e * y)
            await asyncio.sleep(MOVE_DT)
        await self.page.mouse.move(x, y)
        self.x, self.y = x, y

    async def follow(self, pts, dur):
        """glide continuously along a spline through pts (ambient motion)"""
        path, cum = build_path(pts)
        ts = time.perf_counter()
        while True:
            u = (time.perf_counter() - ts) / dur
            if u >= 1:
                break
            x, y = path_at(path, cum, 0.5 - 0.5 * math.cos(math.pi * u))
            await self.page.mouse.move(x, y)
            self.x, self.y = x, y
            await asyncio.sleep(MOVE_DT)
        self.x, self.y = pts[-1]
        await self.page.mouse.move(*pts[-1])

    async def press(self, hold=0.09):
        await self.page.mouse.down()
        await asyncio.sleep(hold)
        await self.page.mouse.up()

    async def box(self, sel, nth=0):
        loc = self.page.locator(sel).nth(nth)
        try:
            await loc.scroll_into_view_if_needed(timeout=2500)
        except Exception:
            pass
        bb = await loc.bounding_box()
        if not bb:
            raise RuntimeError("not visible: " + sel)
        return bb

    async def click(self, sel, dur=0.5, nth=0):
        bb = await self.box(sel, nth)
        await self.glide(bb["x"] + bb["width"] / 2, bb["y"] + bb["height"] / 2, dur)
        await self.press()

    async def slide_far(self, sid, target=None, approach=0.42, drag=0.68):
        """grab the slider thumb and drag it to the far side of where it is now"""
        loc = self.page.locator("#" + sid)
        bb = await self.box("#" + sid)
        mn, mx, val = await loc.evaluate("e => [+e.min, +e.max, +e.value]")
        frac = target if target is not None else (0.9 if (val - mn) / ((mx - mn) or 1) < 0.5 else 0.1)
        tw = 20
        span = bb["width"] - tw
        px = lambda v: bb["x"] + tw / 2 + (v - mn) / ((mx - mn) or 1) * span
        y = bb["y"] + bb["height"] / 2
        await self.glide(px(val), y, approach)
        await self.page.mouse.down()
        await asyncio.sleep(0.06)
        await self.glide(px(mn + frac * (mx - mn)), y, drag)
        await asyncio.sleep(0.10)
        await self.page.mouse.up()

    async def tiles(self):
        try:
            return await self.page.evaluate(TILES_JS)
        except Exception:
            return []

async def visible_ids(page, ids):
    try:
        return await page.evaluate(VISIBLE_JS, ids)
    except Exception:
        return []

# ───────────────────────── THE 4 PLANNED SCENARIOS ─────────────────────────
# 1) AMBIENT CURSOR — one long, silky, click-free drift: reads every letter
#    left→right, loops under the canvas and back over the top, then settles.
async def sc_ambient(r, D):
    bb = await r.box("#canvas")
    at = lambda fx, fy: (bb["x"] + bb["width"] * fx, bb["y"] + bb["height"] * fy)
    pts = [(r.x, r.y)]
    ts = sorted(await r.tiles(), key=lambda t: t["x"])
    if len(ts) >= 3:
        step = max(1, len(ts) // 7)
        for i, t in enumerate(ts[::step]):
            pts.append((t["x"], t["y"] + (-26 if i % 2 else 26)))
    else:
        pts += [at(.2, .4), at(.4, .6), at(.6, .4), at(.8, .6)]
    pts += [at(.82, .86), at(.52, .92), at(.2, .84), at(.10, .42),
            at(.34, .12), at(.70, .14), at(.90, .42), at(.62, .62)]
    pts = [(min(max(x, 8), r.W - 8), min(max(y, 8), r.H - 8)) for x, y in pts]
    await r.until(0.4)
    await r.follow(pts, D - 0.4 - 0.7)

# 2) TAB ICONS — click every tab icon in turn; after each click the cursor
#    drifts into the opened panel so the new controls are visible, then moves on.
async def sc_tabs(r, D):
    tabs = await r.page.evaluate("() => [...document.querySelectorAll('.tab')].map(t => t.dataset.t).filter(Boolean)")
    uniq = list(dict.fromkeys(tabs))
    if len(uniq) < 2:
        raise RuntimeError("tabs not found")
    order = uniq[1:] + uniq[:1]
    first, tail = 1.0, 1.5
    slot = (D - first - tail) / len(order)
    panel = ".panel" if await r.page.locator(".panel").count() else ".sections"
    for i, tid in enumerate(order):
        t0 = first + i * slot
        await r.until(t0)
        await r.click(f'.tab[data-t="{tid}"]', min(0.65, slot * 0.27))
        await r.until(t0 + slot * 0.40)
        pb = await r.box(panel)
        await r.glide(pb["x"] + pb["width"] * r.rng.uniform(.35, .65),
                      pb["y"] + pb["height"] * r.rng.uniform(.35, .60), slot * 0.30)
    await r.until(first + len(order) * slot)
    cb = await r.box("#canvas")
    await r.glide(cb["x"] + cb["width"] * .62, cb["y"] + cb["height"] * .72, 1.0)

# 3) PAPER SLIDERS — drag 5 paper sliders one after another, then park the cursor
#    on the canvas and HOLD (≥ SLIDER_HOLD s) so the delayed effects finish rendering.
async def sc_sliders(r, D):
    plan = [("age", .85), ("folds", .80), ("bleed", .80), ("smear", .75), ("fibers", .85),
            ("tearH", .90), ("tearV", .15), ("dropout", .55)]
    vis = await visible_ids(r.page, [p[0] for p in plan])
    plan = [p for p in plan if p[0] in vis] + [p for p in plan if p[0] not in vis]
    PER, START = 1.5, 0.9
    n = max(2, min(5, int((D - START - SLIDER_HOLD) / PER + 1e-6)))
    await r.until(START)
    done = 0
    for sid, tgt in plan:
        if done >= n or r.now() + 1.3 > D - SLIDER_HOLD:
            break
        try:
            await r.slide_far(sid, tgt)
        except Exception as e:
            r.log.append(f"slider {sid} skipped ({type(e).__name__})")
            continue
        done += 1
        await r.sleep(0.25)
    if done == 0:
        raise RuntimeError("no paper sliders could be dragged")
    r.log.append(f"{done} sliders moved, last released at {r.now():.1f}s → hold {D - r.now():.1f}s")
    await r.sleep(0.35)
    cb = await r.box("#canvas")
    await r.glide(cb["x"] + cb["width"] * .80, cb["y"] + cb["height"] * .80, 1.0)

# pre-roll hook: park the side panel scrolled to the bottom BEFORE recording starts
# (Paper tab: Age/Folds/Bleed/Dropout/Smear all in view; Style tab: Shuffle in view)
async def pre_scroll_bottom(page):
    await page.evaluate("() => { const s = document.querySelector('.sections'); if (s) s.scrollTo({top: s.scrollHeight, behavior: 'instant'}); }")
    await page.wait_for_timeout(300)

# 4) SHUFFLE — glide to Shuffle, 5 relaxed clicks (result visible each time),
#    then a 3-click rapid burst, then park on the canvas to show the final layout.
async def sc_shuffle(r, D):
    bb = await r.box("#shuffleBtn")
    cx, cy = bb["x"] + bb["width"] / 2, bb["y"] + bb["height"] / 2
    await r.until(0.4)
    await r.glide(cx, cy, 0.9)
    for t in (1.5, 3.3, 5.1, 6.9, 8.7, 10.5, 11.0, 11.5):
        await r.until(t)
        await r.press()
    await r.until(12.2)
    cb = await r.box("#canvas")
    await r.glide(cb["x"] + cb["width"] * .78, cb["y"] + cb["height"] * .80, 1.0)

CLIPS = [
    dict(file="01_ambient_cursor",  word="BANDIT", preset="Punk Cover",     tab="text",  fn=sc_ambient, start=(.50, .60)),
    dict(file="02_tab_icon_clicks", word="SECRET", preset="Riso Poster",    tab="text",  fn=sc_tabs,    start=(.55, .55)),
    dict(file="03_paper_sliders",   word="WANTED", preset="Crime Headline", tab="paper", fn=sc_sliders, start=(.62, .50), pre=pre_scroll_bottom),
    dict(file="04_shuffle_clicks",  word="RACKET", preset="Xerox Zine",     tab="style", fn=sc_shuffle, start=(.55, .55), pre=pre_scroll_bottom),
]
# ═══ @@LIB_END ═══

# ───────────────────────── recording + encoding ─────────────────────────
class Recorder:
    def __init__(self, ctx, page, w, h, dsf):
        self.ctx, self.page = ctx, page
        self.mw, self.mh = int(w * dsf), int(h * dsf)
        self.frames, self.cdp = [], None

    async def _ack(self, sid):
        try:
            await self.cdp.send("Page.screencastFrameAck", {"sessionId": sid})
        except Exception:
            pass

    def _on(self, ev):
        ts = (ev.get("metadata") or {}).get("timestamp") or time.time()
        self.frames.append((ts, ev["data"]))
        asyncio.ensure_future(self._ack(ev["sessionId"]))

    async def start(self):
        self.cdp = await self.ctx.new_cdp_session(self.page)
        self.cdp.on("Page.screencastFrame", self._on)
        await self.cdp.send("Page.startScreencast", {
            "format": "jpeg", "quality": JPEG_QUALITY,
            "maxWidth": self.mw, "maxHeight": self.mh, "everyNthFrame": 1})

    async def stop(self):
        try:
            await self.cdp.send("Page.stopScreencast")
            await self.cdp.detach()
        except Exception:
            pass

def write_frames(frames, dur, tmpdir):
    os.makedirs(tmpdir, exist_ok=True)
    t0 = frames[0][0]
    keep = [(ts, b) for ts, b in frames if ts - t0 < dur - 0.02]
    lines, fn = [], ""
    for i, (ts, b64) in enumerate(keep):
        fn = f"f{i:05d}.jpg"
        with open(os.path.join(tmpdir, fn), "wb") as f:
            f.write(base64.b64decode(b64))
        nxt = keep[i + 1][0] if i + 1 < len(keep) else t0 + dur
        lines.append(f"file '{fn}'\nduration {max(0.001, nxt - ts):.4f}")
    lines.append(f"file '{fn}'")
    with open(os.path.join(tmpdir, "list.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")
    return len(keep)

async def encode(tmpdir, out_path, vf, dur):
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
           "-i", os.path.join(tmpdir, "list.txt"), "-vf", vf, "-t", f"{dur:.3f}",
           "-c:v", "libx264", "-preset", "slow", "-crf", str(CRF), "-pix_fmt", "yuv420p",
           "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
           "-movflags", "+faststart", "-an", out_path]
    p = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    out, _ = await p.communicate()
    return p.returncode == 0, out.decode(errors="ignore")[-500:]

def probe(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0",
                        "-show_entries", "stream=width,height,nb_frames", "-show_entries", "format=duration",
                        "-of", "default=nw=1", path], capture_output=True, text=True)
    return dict(l.split("=", 1) for l in p.stdout.split() if "=" in l)

async def prep(page, spec):
    await page.evaluate("""([word, preset, tab]) => {
        document.querySelector('.tab[data-t="text"]').click();
        if (preset) applyPreset(preset);
        const s = document.getElementById('ctype'); if (s) { s.value = 'letters'; onTypeChange(); }
        const t = document.getElementById('textInput'); t.value = word; onTextInput();
        if (tab !== 'text') document.querySelector('.tab[data-t="' + tab + '"]').click();
    }""", [spec["word"], spec["preset"], spec["tab"]])

async def ensure_light(page):
    for _ in range(2):
        lum = await page.evaluate(LIGHT_JS)
        if lum is None or lum >= 0.45:
            return "light ✔" if lum is not None else "light (assumed)"
        await page.evaluate("() => { const b = document.querySelector('.theme-toggle'); if (b) b.click(); }")
        await page.wait_for_timeout(700)
    return "⚠ page still looks dark"

async def make_clip(browser, spec, out_path, D):
    cfg = DESKTOP
    W, H = cfg["w"], cfg["h"]
    OW, OH = int(W * cfg["dsf"]), int(H * cfg["dsf"])
    ctx = await browser.new_context(viewport={"width": W, "height": H}, device_scale_factor=cfg["dsf"],
                                    is_mobile=False, has_touch=False, color_scheme="light", locale="en-US")
    await ctx.add_init_script(CURSOR_JS)
    page = await ctx.new_page()
    page.set_default_timeout(8000)
    rec = None
    try:
        await page.goto(URL, wait_until="load", timeout=60000)
        try:
            await page.wait_for_load_state("networkidle", timeout=8000)
        except Exception:
            pass
        try:
            await page.evaluate("document.fonts.ready.then(() => true)")
        except Exception:
            pass
        await prep(page, spec)
        await page.wait_for_timeout(1800)
        theme = await ensure_light(page)
        letters = await page.locator("#letterStrip .letter-btn").count()
        print(f"     word={spec['word']}  letter buttons={max(0, letters - 1)}  theme={theme}", flush=True)
        if spec.get("pre"):
            await spec["pre"](page)
        rig = Rig(page, random.Random(SEED + len(spec["file"])), W, H)
        await rig.place(W * spec["start"][0], H * spec["start"][1])
        rec = Recorder(ctx, page, W, H, cfg["dsf"])
        await rec.start()
        for _ in range(40):
            if rec.frames:
                break
            await page.wait_for_timeout(50)
        if not rec.frames:
            await page.mouse.move(rig.x + 1, rig.y)
            await page.wait_for_timeout(300)
        rig.t0 = time.perf_counter()
        err = None
        try:
            await asyncio.wait_for(spec["fn"](rig, D), timeout=D + 6)
        except Exception as e:
            err = e
        overran = rig.now() > D + 0.15
        await rig.until(D)
        await rec.stop()
        for line in rig.log:
            print("     ·", line, flush=True)
        if err is not None:
            return None, f"scenario error: {type(err).__name__}: {str(err)[:140]}", False
        if not rec.frames:
            return None, "no frames captured", False
        tmp = os.path.join(TMP_ROOT, spec["file"])
        shutil.rmtree(tmp, ignore_errors=True)
        n = write_frames(rec.frames, D, tmp)
        vf = (f"fps={FPS},scale={OW}:{OH}:flags=lanczos+accurate_rnd+full_chroma_int:"
              f"in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p")
        ok, log = await encode(tmp, out_path, vf, D)
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"     captured {n} raw frames (~{n / D:.0f} fps source)", flush=True)
        return (out_path if ok else None), ("" if ok else "ffmpeg: " + log), overran
    finally:
        if rec:
            await rec.stop()
        await ctx.close()


# ───────────────────────── MAIN ─────────────────────────
async def main():
    words = [c["word"] for c in CLIPS]
    assert all(len(w) == 6 for w in words) and len(set(words)) == 4 and "CUTOUT" not in words
    shutil.rmtree(ROOT, ignore_errors=True)
    os.makedirs(ROOT, exist_ok=True)
    made = []
    print(f"🎬 Recording 4 clips x {DURATION:.0f}s at {DESKTOP['w'] * DESKTOP['dsf']:.0f}x{DESKTOP['h'] * DESKTOP['dsf']:.0f}, light mode…", flush=True)
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(args=[
            "--no-sandbox", "--disable-dev-shm-usage", "--hide-scrollbars", "--force-color-profile=srgb",
            "--font-render-hinting=none", "--disable-background-timer-throttling",
            "--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows"])
        for i, spec in enumerate(CLIPS, 1):
            out_path = os.path.join(ROOT, spec["file"] + ".mp4")
            print(f"  🎥 [{i}/4] {spec['file']}", flush=True)
            best = None
            for attempt in range(1, 4):
                try:
                    path, msg, overran = await make_clip(browser, spec, out_path, DURATION)
                except Exception as e:
                    path, msg, overran = None, f"{type(e).__name__}: {str(e)[:140]}", False
                if path and not overran:
                    best = path
                    break
                if path:
                    best = path
                    print(f"     ↻ attempt {attempt}: scenario ran late — retrying for a clean take", flush=True)
                else:
                    print(f"     ↻ attempt {attempt} failed — {msg}", flush=True)
            if best:
                pr = probe(best)
                made.append((os.path.basename(best), spec["word"], pr.get("width"), pr.get("height"), pr.get("duration")))
                print(f"  ✅ {os.path.basename(best)}  {pr.get('width')}x{pr.get('height')}  {float(pr.get('duration', 0)):.2f}s", flush=True)
            else:
                print(f"  ⚠️ {spec['file']} could not be recorded", flush=True)
        await browser.close()
    with open(os.path.join(ROOT, "_manifest.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["file", "word", "width", "height", "seconds"])
        w.writerows(made)
    shutil.rmtree(TMP_ROOT, ignore_errors=True)
    return len(made)

if __name__ == "__main__":
    n_ok = asyncio.run(main())
    print(f"🎉 Done: {n_ok}/4 clips in {ROOT}", flush=True)
    sys.exit(0 if n_ok == 4 else 1)
